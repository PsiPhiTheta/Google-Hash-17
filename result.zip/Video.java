public class Video
{
	final int size;
	final int id;
	public Video(int givenSize, int givenId)
	{
		size = givenSize;
		id = givenId;
	}
}